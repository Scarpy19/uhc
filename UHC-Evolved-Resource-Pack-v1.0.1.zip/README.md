UHC EVOLVED Resource Pack
Developed by TheFatSanta
Version: 1.0.1

VERSION COMPATIBILITY
This Resource Pack currently supports release versions 1.20.3 - 1.20.6

For any issues with the UHC EVOLVED gamemode, reach out to TheFatSanta on discord from the UHC EVOLVED discord server:
https://discord.gg/THzVNUrmDa

Copyright 2024 TheFatSanta

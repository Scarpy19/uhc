UHC EVOLVED Resource Pack
Developed by TheFatSanta
Textures by Pinkessi
v1.2.1

VERSION COMPATIBILITY
This Resource Pack currently supports the version 1.21.3


Fish Textures were created by Athesiel
You can find Athesiel's custom datapack that the textures were created for here:
https://www.minecraftforum.net/forums/mapping-and-modding-java-edition/minecraft-mods/3043897-vanilla-1-16-4-revamped-fishing-139-new-fish-new


For any issues with the UHC EVOLVED gamemode, reach out to TheFatSanta on discord from the UHC EVOLVED discord server:
https://discord.gg/THzVNUrmDa

Copyright 2024 TheFatSanta
